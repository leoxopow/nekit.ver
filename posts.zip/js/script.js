$(document).ready(function() {
    if (window.PIE) {
        $('.header').each(function() {
            PIE.attach(this);
        });
    }
});